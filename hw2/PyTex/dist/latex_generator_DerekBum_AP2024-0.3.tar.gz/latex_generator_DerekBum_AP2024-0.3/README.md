# Latex generator

This package allows user to generate:
1) A table by two-dimensional table.
2) A picture using provided png file.